def count_in_list(lst, item):
    """ Count the number of times an item appears in a list """
    return lst.count(item)